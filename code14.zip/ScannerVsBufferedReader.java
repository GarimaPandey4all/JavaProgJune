import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class ScannerVsBufferedReader {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter your age");
		int age = Integer.parseInt(br.readLine());
		
		System.out.println("Enter your name");
		String name = br.readLine();
		
		System.out.println("Your age and name is "+age+" "+name);
		
		//By using Scanner
		/*
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter your age");
		int age = scanner.nextInt();
		
		System.out.println("Enter your name");
		String name = scanner.nextLine();
		
		System.out.println("Your age and name is "+age+" "+name);

		*/
	}

}
