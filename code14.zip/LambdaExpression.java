
interface Add {
	int add(int a, int b);
}

public class LambdaExpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Add add = (a, b)->(a + b);
		System.out.println(add.add(10, 20));
		
		//Method - 2
		Add add2 = (int a, int b)->(a + b);
		System.out.println(add2.add(10, 20));

	}

}
