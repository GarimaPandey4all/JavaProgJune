package com.brainmentors.java.oops;

public class FinalizeExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FinalizeExample obj = new FinalizeExample();
		
		obj = null;
		
		//Requiring JVM to call Garbage Collector Method
		System.gc();
		System.out.println("Main Completes");

	}
	
	//Here overriding finalize method
	public void finalize()
	{
		System.out.println("Finalize Method Overridden");
	}

}
