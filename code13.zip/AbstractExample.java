package com.brainmentors.java.oops;

/*
 * 1. Abstract class can have abstract methods
 * 2. You can't create objects of abstract class.
 * */
abstract class DemoParent {
	private String name;
	private int age;
	
	public DemoParent(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	
	public void printData()
	{
		System.out.println(name+" "+age);
	}
	
	/*
	 * 1. Abstract method is method that can only be declared, not defined.
	 * 
	 * */
	public abstract void contNumber();
}

class DemoStudent extends DemoParent{
	
	private int id;
	
	public DemoStudent(int id)
	{
		super("Ram", 25);
		this.id = id;
	}
	
	public void printId()
	{
		System.out.println(id);
	}
	
	@Override 
	public void contNumber()
	{
		System.out.println("Student's Contact Number");
	}
}



public class AbstractExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DemoStudent demo = new DemoStudent(100);
		demo.printId();
		demo.printData();
		demo.contNumber();
		
	}

}
