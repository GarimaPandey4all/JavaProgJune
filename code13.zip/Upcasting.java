package com.brainmentors.java.oops;

class ParentDemo {
	void printData()
	{
		System.out.println("Method of Parent Class");
	}
}

class ChildDemo extends ParentDemo {
	@Override
	void printData()
	{
		System.out.println("Method of Child Class");
	}
}

public class Upcasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Upcasting: Child object type cast into Parent Object
		
		ParentDemo obj1 = (ParentDemo)new ChildDemo();
		ParentDemo obj2 = (ParentDemo)new ChildDemo();
		
		obj1.printData();
		obj2.printData();

	}

}
