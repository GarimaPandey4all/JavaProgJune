package com.brainmentors.java.oops;

/*
 * 1. It is used to achieve total abstraction
 * 2. It supports multiple inheritance
 * 3. Interfaces contains abstract methods
 * 
 * **/

//Multiple Interface(Inheritance)

interface Printable {
	void print();
}

interface Showable {
	void show();
}

class ChildInterface implements Printable, Showable {
	
	public void print()
	{
		System.out.println("Hello");
	}
	public void show()
	{
		System.out.println("Welcome");
	}
}


public class InterfacesExample {
	
	public static void main(String[] args) {
		
		ChildInterface obj = new ChildInterface();
		obj.print();
		obj.show();
		
	}

}
