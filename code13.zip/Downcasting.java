package com.brainmentors.java.oops;

class ParentDemo1 {
	void printData()
	{
		System.out.println("Method of Parent Class");
	}
}

class ChildDemo1 extends ParentDemo1 {
	@Override
	void printData()
	{
		System.out.println("Method of Child Class");
	}
}

public class Downcasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Downcasting: Parent object type cast into Child(Indirectly) Object
		
		ParentDemo1 parent = new ChildDemo1();
		
		ChildDemo1 child = (ChildDemo1)parent;
		
		child.printData();

	}

}

