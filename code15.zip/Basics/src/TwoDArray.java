
public class TwoDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int matrix1[][] = {	{1, 3},
							{4, 5}}; 
		

		int matrix2[][] = {	{2, 7},
							{4, 6}}; 
		
		int m = matrix1.length;
		int n = matrix1[0].length;
		
		int result[][] = new int[m][n];
		
		//System.out.println(matrix1.length); // get rows length
		//System.out.println(matrix1[0].length); // get columns length

		
		
		for(int i = 0; i < matrix1.length; i++)
		{
			for(int j = 0; j < matrix1[0].length; j++)
			{
				result[i][j] = matrix1[i][j] + matrix2[i][j];
			}
		}
		
		System.out.println("Addition of two matrices ");
		for(int i = 0; i < matrix1.length; i++)
		{
			for(int j = 0; j < matrix1[0].length; j++)
			{
				System.out.print(result[i][j]+"  ");
			}
			
			System.out.println();
		}
		
	}

}
