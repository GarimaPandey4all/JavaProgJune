
public class OneDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		Array: It is a collection of similar types of data.
		[] - Closed Bracket or Subscript Operator
		
		It is a continuous Memory Allocation
		*/
		
		int arr[] = {10, 20, 30, 40, 50};
		
		System.out.println(arr[0]); // 10
		System.out.println(arr[3]); // 40
		
		for(int i = 0; i < arr.length; i++)
		{
			System.out.println(arr[i]);
		}

	}

}
