
public class Switch2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num =5;
		
		//fall through
		switch(num)
		{
		case 5:
			System.out.println("Case 5");
		case 10:
			System.out.println("Case 10");
		default:
			System.out.println("Invalid Choice");
		}
		
		/*
		switch(num)
		{
		case 5:
			System.out.println("Case 5");
			break;
		case 10:
			System.out.println("Case 10");
			break;
		default:
			System.out.println("Invalid Choice");
		}*/

	}

}
