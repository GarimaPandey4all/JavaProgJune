import java.util.Scanner;

public class SwitchConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Switch with string
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your choice");
		String choice = sc.nextLine();
		
		/*
		if(choice == "one")
		{
			
		}
		else if(choice == "two")
		{
			
		}*/
		
		switch(choice)
		{
		case "one":
			System.out.println("One");
			break;
			
		case "two":
			System.out.println("Two");
			break;
			
		case "three":
			System.out.println("Three");
			break;
			
		default:
			System.out.println("No Match");
		}

		//System.out.println("Outside the switch");
	}

}
