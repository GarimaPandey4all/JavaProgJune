
public class TOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Ternary - 3 Operator / Conditional Operator (shorthand if-else)- ?:
		
		//(condition) ? true : false;
		
		int num = 17;
		
		String result = (num % 2 == 0) ? "Even" : "Odd";
		
		System.out.println(result);
 
	}

}
