
public class String1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "Ram"; // 1 or 0
		String name2 = "Ram";
		String name3 = new String("Ram").intern(); // 1 or 2
		String name4 = new String("Ram"); // 1 or 2
		
		// ==(address) or equals(value)
		System.out.println(name == name2);
		System.out.println(name == name3);
		System.out.println(name3 == name4);
		
		String t = "Hello";
		String y = t;
		
		System.out.println(y == t);
		
		t = t+" How are you"; // string objects are immutable
		System.out.println(y == t);
	}

}
