import java.util.ArrayList;

public class Unboxing {
	
	public static void main(String[] args) {
		
		Character ch = 'z';
		
		//Unboxing- Character to char
		
		char a = ch;
		
		System.out.println(a);
		
		ArrayList<Integer> arrayList = new ArrayList<>();
		arrayList.add(100);
		
		//Unboxing: Because get method returns an Integer Object
		int num =  arrayList.get(0);
		
		//Printing the value from primitive data types
		System.out.println(num);
		
	}

}
