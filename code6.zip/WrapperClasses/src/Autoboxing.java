import java.util.ArrayList;

public class Autoboxing {
	
	public static void main(String[] args) {
		char ch = 'z';
		
		//Autoboxing: char to Character
		
		Character a = ch;
		System.out.println(a);
		
		ArrayList<Integer> arrayList = new ArrayList<>();
		
		//Autoboxing: Because Array List stores only objects
		arrayList.add(10);
		arrayList.add(20);
		
		//Printing the values from object
		System.out.println(arrayList.get(1));
		
	}

}
