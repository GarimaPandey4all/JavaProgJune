
public class Student {
	
	int rollno;
	String name;
	String phone;
	String courses;
	double fees;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student ram = new Student();
		
		System.out.println("Rollno "+ram.rollno);
		System.out.println("Name "+ram.name);
		System.out.println("Phone "+ram.phone);
		System.out.println("Courses "+ram.courses);
		System.out.println("Fees "+ram.fees);
		
		ram.rollno = 1001;
		ram.name = "Ram Kumar";
		ram.phone= "328478532";
		ram.courses = "MCA";
		ram.fees = 100000.0;
		
		System.out.println("*************************************************************************");
		
		System.out.println("Rollno "+ram.rollno);
		System.out.println("Name "+ram.name);
		System.out.println("Phone "+ram.phone);
		System.out.println("Courses "+ram.courses);
		System.out.println("Fees "+ram.fees);
		
		//Student shyam = new Student();
	}

}
