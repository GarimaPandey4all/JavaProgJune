class Variable {
    public static void main(String[] args) {
        //variable - Container
        //vary or change

        int firstNumber = 100; // local variables
        int secondNumber = 200;
        int result;

        result = firstNumber + secondNumber;

        System.out.println("Sum is "+result);

        /*
            -Java doesn't have garbage value
            -It throws error
            -Local variables must be initialized before use
            -Otherwise compilation fails
        */
        
    }
}
