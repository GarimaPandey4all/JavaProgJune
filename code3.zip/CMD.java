class CMD {
    public static void main(String[] args) {
        /* - Wrong Way
        String firstNumber = args[0];
        String secondNumber = args[1];
        String result = firstNumber + secondNumber;
        */

        if(args.length == 2){
            int firstNumber = Integer.parseInt(args[0]);
            int secondNumber = Integer.parseInt(args[1]);

            int result = firstNumber + secondNumber;

            System.out.println("Sum is "+result); // +  - concatenation/joining
        }
        else {
            System.out.println("Invalid Input");
        }
    }
}
