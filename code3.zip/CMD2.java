class CMD2 {
    public static void main(String[] args) {
        int sum = 0;
        
        //Traditional Loop
        /*
        for(int i = 0; i < args.length; i++)
        {
            sum = sum + Integer.parseInt(args[i]);
        }*/

        //Enhanced Loop or For Each Loop
        for(String arr : args)
        {
            sum += Integer.parseInt(arr); // shorthand
        }

        System.out.println("Sum is "+sum);
    }
}
