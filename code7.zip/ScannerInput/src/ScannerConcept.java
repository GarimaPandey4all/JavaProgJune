import java.util.Scanner;

public class ScannerConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Declare the object and initialize with predefined standard input object
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your name:");
		//string input
		String name = sc.nextLine();
		
		System.out.println("Enter your gender:");
		//char input
		char gender = sc.next().charAt(0); // char - i character
		 
		System.out.println("Enter your age:");
		int age = sc.nextInt();
		
		System.out.println("Enter your mobile number:");
		long mobileNo = sc.nextLong();
		
		System.out.println("Enter your CGPA:");
		double cgpa = sc.nextDouble();
		
		
		System.out.println("Name: "+name);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Mobile Number: "+mobileNo);
		System.out.println("CGPA: "+cgpa);
		

	}

}
