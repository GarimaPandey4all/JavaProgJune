
public class LabelledLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//without labelled loop
		
		int i, j;
		
		/*
		//nested loops
		for(i = 1; i <= 5; i++) // row
		{
			for(j = 1; j <= 5; j++) // col
			{
				System.out.print(i); // j
				
				if(j == 5)
				{
					break;
				}
			}
			
			System.out.println(); // enter
		}
		*/
		
		//With Labelled Loop
		
		loop1: for(i = 1; i <= 5; i++) // row
		{
		loop2:	for(j = 1; j <= 5; j++) // col
			{
				System.out.print(i); // j
				
				if(j == 5)
				{
					break loop1;
				}
			}
			
			System.out.println(); // enter
		}
	}

}
