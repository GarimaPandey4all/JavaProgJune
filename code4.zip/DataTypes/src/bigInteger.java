import java.math.BigInteger;

public class bigInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//With using BigDecimal
		
		BigInteger a = new BigInteger("8734698795");
		BigInteger b = new BigInteger("2346827346");
		BigInteger c = b.add(a); // b + a
		System.out.println(c);

	}

}
