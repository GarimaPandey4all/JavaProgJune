
public class Types {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//first solution
		//float pi = 3.14f;
		
		//second solution
		float pi = (float)3.14; // type casting / type conversion
		
		double w = 3278.9879;
		
		//char
		char c = 'f';
		
		//boolean - true /false
		boolean b = true;
		
		//Reference Data Type
		String name = "Ram Kumar";
		
		String n = name;
		
		

	}

}
