import java.math.BigDecimal;

public class bigDecimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//With using BigDecimal
		
		BigDecimal a = new BigDecimal("0.03");
		BigDecimal b = new BigDecimal("0.04");
		BigDecimal c = b.subtract(a); // b - a
		System.out.println(c);
		
		//Without using bigdecimal
		/*
		double a = 0.03;
		double b = 0.04;
		double c = b - a;
		
		System.out.println(c);*/

	}

}
