
public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Main difference between equals() method and == operator is that one is method and other is operator.
		
		// == reference/address comparison
		// equals() - content comparison
		
		String s1 = new String("Hello");
		String s2 = new String("Hello");
		
		System.out.println(s1 == s2); // false // == operator
		System.out.println(s1.equals(s2)); // true // equals()

	}

}
