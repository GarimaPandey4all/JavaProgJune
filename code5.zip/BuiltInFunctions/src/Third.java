
public class Third {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Second Way
		
		String str1 = "leetcode";
		String str2 = "leetcode";
		String str3 = "astha";
		
		System.out.println(str1.compareTo(str2));
		System.out.println(str1.compareTo(str3));
		
		//First Way
		/*
		String str1 = "leetcode";
		String str2 = new String("leetcode");
		String str3 = new String("astha"); // a - 97, l = 108 
		
		System.out.println(str1.compareTo(str2));
		if(str1.compareTo(str2) == 0)
		{
			System.out.println("Strings are same");
		}
		else {
			System.out.println("Strings are not same");
		}
		
		System.out.println(str1.compareTo(str3));
		*/
	}
}
