package com.brainmentors.java.oops;

//Parent Class
class Person1 {
	
	private String name;
	
	public Person1()
	{
		name = "Brain Mentors";
	}
	
	public void printName()
	{
		System.out.println("Name of the person is: "+name);
	}
	
	public void contNumber()
	{
		System.out.println("Contact number of person");
	}
}

// Student - Child Class
class Student2 extends Person1 { // Class Relationship - Inheritance 
	
	private int id;
	
	public Student2()
	{
		//super(); - Parent Default Cons Call (Implicit Super Call) 
		id = 100;
	}
	
	public void printId()
	{
		System.out.println("Student id is "+id);
	}
}

class Employee extends Person1{
	
	private int salary;
	
	public Employee()
	{
		salary = 50000;
	}
	
	public void printSalary()
	{
		System.out.println("Employee Salary is "+salary);
	}
	
	@Override
	public void contNumber()
	{	
		super.contNumber(); // super ka mtlb hamesha upr hota h
		System.out.println("Contact number of Employee");
	}
}

public class Overriding {

	public static void main(String[] args) {
		Student2 student = new Student2();
		student.printId();
		student.printName();
		student.contNumber();
		
		Employee emp = new Employee();
		emp.printSalary();
		emp.contNumber();
	}
}
