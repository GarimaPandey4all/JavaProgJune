package com.brainmentors.java.oops;

//3. final class 
final class Parent {
	// 2. final method example
	public final void showData()
	{
		System.out.println("Parent Method");
	}
}

class Child extends Parent {
	
	/*
	@Override
	public void showData() // can't override the parent method as parent is final method
	{
		System.out.println("Child Method");
	}*/
}

public class FinalKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1. final variable example
		final int a = 10;
		
		System.out.println(a);
		
		//a = 50;

	}

}
