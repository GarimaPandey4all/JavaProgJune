package com.brainmentors.java.oops;

class A {
	int x; // instance variable
	
	A()
	{
		System.out.println("A defualt Cons Call");
	}
	A(int x)
	{
		this(); // A default cons call
		this.x = x;
		System.out.println("A param cons call "+x);
	}
}

class B extends A { // inheritance
	int x;
	
	B()
	{
		super(200);  // A default cons call
		System.out.println("B default Cons Call");
	}
	B(int x)
	{
		this(); // b default cons call
		//super(200);
		this.x= x;
		System.out.println("B param cons call "+x);
	}
}

public class SpuervsThis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		B obj = new B(100);
		
		/*
		// calling steps:
		1. B param cons call
		2. B default cons call
		3. A param cons call
		4. A default cons call
		
		//printing teps:
		1. A defualt Cons Call
		2. A param cons call 200
		3. B default Cons Call
		4. B param cons call 100
		*/
	}

}
