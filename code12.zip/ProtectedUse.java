package com.brainmentors.java.oops;

class personNew {
	protected String name = "Brain Mentors";
}

class StudentNew extends personNew {
	public void print()
	{
		System.out.println(name);
	}
}

public class ProtectedUse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StudentNew obj = new StudentNew();
		obj.print();

	}

}
