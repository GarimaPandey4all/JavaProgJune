package com.brainmentors.java.oops;

//Parent Class
class Person {
	
	private String name;
	
	public Person()
	{
		name = "Brain Mentors";
	}
	
	public void printName()
	{
		System.out.println("Name of the person is: "+name);
	}
}

// Student - Child Class
class Student extends Person { // Class Relationship - Inheritance 
	
	private int id;
	
	public Student()
	{
		//super(); - Parent Default Cons Call (Implicit Super Call) 
		id = 100;
	}
	
	public void printId()
	{
		System.out.println("Student id is "+id);
	}
}

public class ISADemo {

	public static void main(String[] args) {
		Student student = new Student();
		student.printId();
		student.printName();
	}
}
