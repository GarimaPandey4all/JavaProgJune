package com.brainmentors.java.oops;

public class Student1 {
	
	private int id;
	private String name;
	private double fees;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public Student1(int id, String name, double fees) {		
		this(id, name);
		this.fees = fees;
	}
	
	public Student1(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public void printData()
	{
		System.out.println(id);
		System.out.println(name);
		System.out.println(fees);
	}
	
	public static void main(String[] args) {
		Student1 shyam = new Student1(100, "Shayam Sharma", 8668.78);
		shyam.printData();
	}

}
