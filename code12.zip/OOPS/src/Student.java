
public class Student {
	
	//instance/member variables
	private int rollno; // private member variables : Data Hiding
	private String name;
	private String phone;
	private String courses;
	private double fees;
	private String collegeName;
	
	//getter
	public String getPhone() {
		return phone;
	}

	//setter
	public void setPhone(String phone) {
		this.phone = phone;
	}

	Student() // default constructor
	{
		collegeName = "SRCC";
	}
	
	Student(int rollno, String name, String phone, String courses, double fees)
	{
		this(); // Call to the default constructor
		this.rollno = rollno;
		this.name = name;
		this.phone = phone;
		this.courses = courses;
		this.fees = fees;
	}
	
	//r, n, p, c, f - these are called local variables
//	public void takeInput(int r, String n, String p, String c, double f)
	public void takeInput(int rollno, String name, String phone, String courses, double fees)
	{
		this.rollno = rollno;
		this.name = name;
		this.phone = phone;
		this.courses = courses;
		this.fees = fees;
		
		//instance variables = local variables
		/*
		rollno = r; 
		name = n;
		phone = p;
		courses = c;
		fees = f;
		*/
	}
	
	public void print()
	{
		System.out.println("Rollno "+this.rollno);
		System.out.println("Name "+name);
		System.out.println("Phone "+phone);
		System.out.println("Courses "+courses);
		System.out.println("Fees "+fees);
		System.out.println("College Name "+collegeName);
	}
	
	//Public member methods
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student ram = new Student(1001, "Ram Kumar", "2345255", "MCA", 1000.0); // call of parameterized constructor
		//ram.takeInput(1001, "Ram Kumar", "2345255", "MCA", 1000.0);
		ram.print();
		ram.setPhone("837417");
		System.out.println("Updated Phone Number " +ram.getPhone());
		ram.print();
		/*
		System.out.println("Rollno "+ram.rollno);
		System.out.println("Name "+ram.name);
		System.out.println("Phone "+ram.phone);
		System.out.println("Courses "+ram.courses);
		System.out.println("Fees "+ram.fees);
		*/
		
		/*
		ram.rollno = -1001;
		ram.name = "Ram Kumar";
		ram.phone= "328478532";
		ram.courses = "MCA";
		ram.fees = 100000.0;
		*/
		
		/*
		System.out.println("*************************************************************************");
		
		System.out.println("Rollno "+ram.rollno);
		System.out.println("Name "+ram.name);
		System.out.println("Phone "+ram.phone);
		System.out.println("Courses "+ram.courses);
		System.out.println("Fees "+ram.fees);
		*/
		//Student shyam = new Student();
	}

}
