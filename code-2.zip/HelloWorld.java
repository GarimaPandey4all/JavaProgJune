class Hello {
    public static void main(String[] args) {
        System.out.println("Hello World");
        System.out.print("Hello World");
        System.out.print("Hello World");
    }
}