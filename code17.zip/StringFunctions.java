
public class StringFunctions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//String name = "     Amit Kumar    ";
		String name = "Amit Kumar";
		
		System.out.println(name.length()); // 4
		
		System.out.println(name.charAt(0)); // A
		
		System.out.println(name.substring(1, 3)); //  1- index, 3 - position
		
		System.out.println(name.trim());
		
		System.out.println(name.replace('u', 'o'));
		
		System.out.println(name.toLowerCase());
		
		System.out.println(name.toUpperCase());
		
		System.out.println(name.concat("New Delhi"));
		
		System.out.println(name+" Mumbai");

		System.out.println(name.contains("mit"));
		
		System.out.println(name.indexOf("i"));
		
		System.out.println(name.lastIndexOf("a"));
	}

}
