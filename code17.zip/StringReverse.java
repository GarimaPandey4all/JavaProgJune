
public class StringReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "Amit Kumar";
		
		StringBuilder sb = new StringBuilder();
		
		sb.append(name);
		
		sb.reverse();
		
		System.out.println(sb);
		
		/*
		char result[] = input.toCharArray();
		
		for(int i = result.length - 1; i >= 0; i--)
		{
			System.out.print(result[i]);
		}
		*/

	}

}
