
public class StringConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		long startTime = System.currentTimeMillis();
		
		StringBuffer sb = new StringBuffer("Java");
		for(int i = 0; i < 10000; i++)
		{
			sb.append("Example");
		}
		
		long endTime = System.currentTimeMillis();

		System.out.println("Time Taken by String Buffer is "+(endTime - startTime));
		
		long startTime2 = System.currentTimeMillis();
		
		StringBuilder sl = new StringBuilder("Java");
		for(int i = 0; i < 10000; i++)
		{
			sl.append("Example");
		}
		
		long endTime2 = System.currentTimeMillis();

		System.out.println("Time Taken by String Builder is "+(endTime2 - startTime2));
	}

}
