
public class StringBufferExample {

	public static void main(String[] args) {
		
		//StringBuffer sb = new StringBuffer();
		StringBuilder sb = new StringBuilder();
		
		System.out.println(sb.capacity()+" "+sb.length());
		
		sb.append("Hello");
		
		System.out.println(sb.capacity()+" "+sb.length());
		
		sb.append("How are you I am fine dfhvbildbifvbfidlubiudfiluvbrnw;iuwnbiwrubtuirwiutubhrtuhggitrh");
		
		System.out.println(sb.capacity()+" "+sb.length());
		
		sb.append("How are");
		
		System.out.println(sb.capacity()+" "+sb.length());
	}
}
