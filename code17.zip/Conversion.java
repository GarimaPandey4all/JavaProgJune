
public class Conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		//1st way, String to Integer
		
		String str = "5";
		
		int result = Integer.parseInt(str);
		
		System.out.println(result);
		
		//2nd way, String to Integer
		
		int result2 = Integer.valueOf(str);
		
		System.out.println(result2);
		*/
	
				int a = 5;
				
				//1st way, Integer to String
				
				String result = Integer.toString(a);
				
				System.out.println(result);
				
				//2nd way, String to Integer
				
				String result2 = String.valueOf(a);
				
				System.out.println(result2);

	}

}
